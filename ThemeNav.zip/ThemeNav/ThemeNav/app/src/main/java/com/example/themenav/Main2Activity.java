package com.example.themenav;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;




public class Main2Activity extends AppCompatActivity {
    private ArrayList<String> list = new ArrayList<String>();
    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        lv = (ListView)findViewById(R.id.listView);
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(
                this, R.layout.list, R.id.a, getData());
        lv.setAdapter(adapter);

    }

    private ArrayList<String> getData()
    {
        list.add("1949");
        list.add("1950");
        list.add("1952");
        list.add("1953");
        list.add("1954");
        list.add("1972");
        list.add("1980");
        list.add("1982");
        list.add("1985");
        list.add("1987");
        list.add("1988");
        list.add("2000");
        list.add("2001");
        list.add("2002");
        list.add("2004");
        list.add("2008");
        list.add("2009");
        list.add("2010");


        return list;
    }
}
