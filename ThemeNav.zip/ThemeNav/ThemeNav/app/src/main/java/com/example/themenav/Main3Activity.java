package com.example.themenav;

import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import android.os.Bundle;
import android.widget.SimpleAdapter;
import android.widget.ListView;



public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        String[] names = new String[]{"Kobe Bryant(8,24)","Wilt Chamberlain(13)","Magic Johnson(32)","Shaquille O'Neal(34)"};
        int[] images = new int[]{R.drawable.kobe,R.drawable.wilt, R.drawable.magic,R.drawable.shark};
        List<HashMap<String, String>> aList =
                new ArrayList<HashMap<String, String>>();

        for (int i = 0; i < images.length; i++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("im", Integer.toString(images[i]));
            hm.put("tx", names[i]);
            aList.add(hm);
        }

        String[] from = {"im", "tx"};
        int[] to = {R.id.im, R.id.tx};

        SimpleAdapter simpleAdapter =
                new SimpleAdapter(getBaseContext(), aList,
                        R.layout.list2, from, to);

        ListView lv = (ListView) findViewById(R.id.listView2);
        lv.setAdapter(simpleAdapter);
    }
}
